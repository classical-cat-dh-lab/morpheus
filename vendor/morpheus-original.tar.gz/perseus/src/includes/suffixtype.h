

typedef Stemtype Suffixtype;

